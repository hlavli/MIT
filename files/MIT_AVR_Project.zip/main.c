/*
 * $safeprojectname$.c
 *
 * Created: 24.09.2024 17:14:31
 * Author : Lenovo L450
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000
#include <util/delay.h>

int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

